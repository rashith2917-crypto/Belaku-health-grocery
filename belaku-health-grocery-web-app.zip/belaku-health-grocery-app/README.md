# Belaku Health & Grocery — Web App

## Run locally
1. Extract this folder.
2. Open `index.html` in a browser to preview the storefront.
3. For install/offline PWA features, serve the folder over HTTPS (or localhost); service workers do not work from ordinary file:// URLs.

## Publish free
You can publish this folder with GitHub Pages or another static HTTPS host. Upload all four files, keeping their names and folder structure.

## Before accepting real orders
- Replace sample products and prices with verified catalogue data.
- Add your store name, address, service areas and verified WhatsApp Business number.
- Connect a secure backend for real order management, customer accounts, inventory and payment processing.
- Add a compliant prescription upload and pharmacist-verification workflow. Do not collect prescriptions through the demo.
- Confirm applicable pharmacy, food, consumer-protection, privacy and tax requirements in India.

This is a front-end demo/PWA. It does not process payments or submit real orders.
